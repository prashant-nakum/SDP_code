
//Lab 8 : 1
import 'package:flutter/material.dart';
void main() => runApp(MaterialApp(
    home: HomeScreen(),
));

    class HomeScreen extends StatelessWidget {


      @override
      Widget build(BuildContext context) {
        return Scaffold(
          appBar: AppBar(
            title: Text(
                'ROWS AND COLUMNS'),
            centerTitle: true,
            backgroundColor: Colors.red[600],
          ),
          body:


/*     //for adding padding
              Center(
         child:Padding(
            padding: EdgeInsets.all(50),
            child: Text('Hello Only Padding'),
          ),
              ),
*/


/*  //for adding rows
Row(
            children: [
              Text('HELLO ROW'),
              FlatButton(onPressed: () {},
                  color: Colors.purple,
                  child: Text('Press me'),
              ),
              Container(
                color: Colors.cyanAccent,
                padding: EdgeInsets.all(30.0),
                child: Text('inside container'),
              ),
            ],
          ),*/

/* // for adding column

 Column(
            //for adding column
              mainAxisAlignment: MainAxisAlignment.end,
              crossAxisAlignment: CrossAxisAlignment.end,

              children: [
                Text('HELLO ROW'),
                FlatButton(onPressed: () {},
                  color: Colors.purple,
                  child: Text('Press me'),
                ),
                Container(
                  color: Colors.cyanAccent,
                  padding: EdgeInsets.all(30.0),
                  child: Text('inside container'),
                ),
                ]
          ),
 */
          
          
        Column(
        mainAxisAlignment: MainAxisAlignment.spaceAround,
        crossAxisAlignment: CrossAxisAlignment.stretch,

        children: [
          Row(
            children: [
              Text('hello ddu,....\n'),
              Text('  ...Hello 5th sem students...')
            ],
          ),


          Container(
          color: Colors.deepOrange[800],
          padding: EdgeInsets.all(30.0),
          child: Text('Inside container 1'),
          ),
      
        Container(
        color: Colors.limeAccent,
        padding: EdgeInsets.all(50.0),
        child: Text('Inside container 2'),
        ),
        Container(
        color: Colors.green[800],
        padding: EdgeInsets.all(70.0),
        child: Text('Inside container 3'),
        ),
        ],
        ),



        floatingActionButton: FloatingActionButton(
            onPressed: () {},
            child: Text('click'),
            backgroundColor: Colors.red[600],
          ),
        );

      }
    }


//LAB 8 : 2.1
/*
import 'package:flutter/material.dart';
void main() => runApp(MaterialApp(
    home: HomeScreen(),
));

    class HomeScreen extends StatelessWidget {


      @override
      Widget build(BuildContext context) {
        return Scaffold(
          backgroundColor: Colors.lightGreen,
          appBar: AppBar(
            title: Text(
                'First App'),
            centerTitle: true,
            backgroundColor: Colors.lightBlue[600],
            elevation: 0.0,
          ),
          body:
          Padding(
            padding: EdgeInsets.fromLTRB(30, 40, 30, 0),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Align(
                  alignment: Alignment.topCenter,

                child: CircleAvatar(

                  backgroundImage: AssetImage('assets/sub_assets/dog2.jpg'),
                  radius: 40.0,
                ),
                ),

                Align(
                  alignment: Alignment.center,
                  child:  Text(
                    '-------------------------------------------------------------------------------------',
                    style: TextStyle(
                      color: Colors.black,
                      letterSpacing: 0.0,
                    ),
                  ),
                ),

                Text(
                  'NAME: ',
                  style: TextStyle(
                    color: Colors.grey[900],
                    letterSpacing: 2.0,
                  ),
                ),
                SizedBox(height: 10),
                Text(
                  'PRASHANT NAKUM',
                  style: TextStyle(
                    color: Colors.blue[900],
                    letterSpacing: 2.0,
                    fontWeight: FontWeight.bold,
                    fontSize: 20.0,
                  ),
                ),
                SizedBox(height: 40),
                Text(
                  'AGE',
                  style: TextStyle(
                    color: Colors.grey[800],
                    letterSpacing: 2.0,
                  ),
                ),

                SizedBox(height: 10),
                Text(
                  '19',
                  style: TextStyle(
                    color: Colors.blue[900],
                    letterSpacing: 2.0,
                    fontWeight: FontWeight.bold,
                    fontSize: 20.0,
                  ),
                ),

                SizedBox(height: 50),
                Row(
                  children: [
                    Icon(
                      Icons.email_rounded,
                      color: Colors.deepPurple[800],
                    ),
                    SizedBox(width: 12.0,),
                    Text(
                      'prashantnakum@gmail.com',
                      style: TextStyle(
                        color: Colors.brown[800],
                        fontSize: 16.0,
                        letterSpacing: 1.5,
                      ),
                    )
                  ],
                )

              ],
            ),
          ),
        );
      }
    }
*/

//lab 8 : 2.2
/*


import 'package:flutter/material.dart';
import 'quote.dart';

void main() => runApp(MaterialApp(
  home: EchoList(),
));

class EchoList extends StatefulWidget {
  const EchoList({Key? key}) : super(key: key);

  @override
  State<EchoList> createState() => _EchoListState();
}

class _EchoListState extends State<EchoList> {

  List<Quote> quotes = [
    Quote(text: 'Simple living and high thinking',author:
    'prashant1'),
    Quote(author: 'prashant2', text: 'Silence and smile are two powerful tool'),
    Quote(text: 'Always do truth',author:
    'prashant1'),
  ];

  Widget quoteTemplate(quote){
    return Card(
      margin: EdgeInsets.fromLTRB(20.0, 30.0, 40.0, 10.0),
      child: Padding(
        padding: const EdgeInsets.all(12.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Text(
              quote.text,
              style: TextStyle(
                fontSize: 20,
                color: Colors.deepPurple,
              ),
            ),
            SizedBox(height: 10),
            Text(
              quote.author,
              style: TextStyle(
                fontSize: 26,
                color: Colors.deepPurple,
              ),
            ),
          ],
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        backgroundColor: Colors.lightBlueAccent[100],
        appBar: AppBar(
        title: Text('Quotes'),
    centerTitle: true,
    backgroundColor: Colors.orangeAccent,
    ),
      body: Column(
// mainAxisAlignment: MainAxisAlignment.center,
// crossAxisAlignment: CrossAxisAlignment.center,
        children: quotes.map((quote) => quoteTemplate(quote)).toList(),
      ),
    );
  }
}
*/
