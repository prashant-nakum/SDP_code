import 'package:lab3_tutorial1/lab3_tutorial1.dart';
import 'package:test/test.dart';

void main() {
  test('calculate', () {
    expect(calculate(), 42);
  });
}
