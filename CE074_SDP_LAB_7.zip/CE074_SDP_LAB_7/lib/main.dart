import 'package:flutter/material.dart';
void main() => runApp(MaterialApp(
    home: HomeScreen(),
)
);

    class HomeScreen extends StatelessWidget {
      @override
      Widget build(BuildContext context) {
        return Scaffold(
          appBar: AppBar(
            title: Text(
                'BUTTON WIDGET APP'),
            centerTitle: true,
            backgroundColor: Colors.red[600],
          ),
          body: Center(
            //for adding textbutton with icon
          child: Directionality(
            textDirection: TextDirection.rtl,
            child: TextButton.icon(
                icon: Icon(
                  Icons.photo_camera,
                  color: Colors.greenAccent,
                  size: 50.0,
                ),
                label: Text(
                  "Gallery",
                  style: TextStyle(
                    color: Colors.black,
                    fontSize: 40.0,
                    letterSpacing: 2.0,
                    backgroundColor: Colors.redAccent,
                  ),
                  textAlign: TextAlign.start,
                ),
              onPressed: () {},
            ),
          ),


/* //for adding image in body
            child: Image(
              image: AssetImage('assets/sub_assets/dog2.jpg'),
            )
           */

/*  //for adding icon in body
child: Icon(
              Icons.flutter_dash,
              color: Colors.amber,
              size: 80.0,
            )*/

/* //for adding elvated button
child: ElevatedButton(
              child: Text('Button'),
              onPressed: () {},
              style: ElevatedButton.styleFrom(
                primary: Colors.purple[800],
                padding: EdgeInsets.symmetric(horizontal: 50, vertical:  20),
                textStyle: TextStyle(
                  fontSize: 40,
                  fontWeight: FontWeight.bold))
            ),*/

/* //for adding flat button
child: FlatButton(
              onPressed: (){
                print('print on consol');
              },
              child: Text('Click Me'),
              color: Colors.blue,
            ), */

/*//for adding icon button
 child: IconButton(
              icon: Icon(
                Icons.mail_outline_sharp,
                size: 30.0,
              ),
              tooltip: 'send mail me',
              onPressed: () {
                print('on console print');
              },
            ),*/

/* //for adding textbutton with icon
            child: TextButton.icon(
                icon: Icon(
                  Icons.photo_camera,
                  color: Colors.greenAccent,
                  size: 50.0,
                ),
            label: Text(
              "Gallery",
              style: TextStyle(
                color: Colors.black,
                fontSize: 40.0,
                letterSpacing: 2.0,
                backgroundColor: Colors.redAccent,
              ),
              textAlign: TextAlign.start,
            ),
              onPressed: () {},
            ),*/

          ),
          floatingActionButton: FloatingActionButton(
            onPressed: () {},
            child: Text('click'),
            backgroundColor: Colors.red[600],
          ),
        );
      }
    }

