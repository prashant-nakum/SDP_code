
//lab 9 first

import 'package:flutter/material.dart';
import 'quote.dart'; // due to same directory file no need path
import 'quote_card.dart'; // relative path
//import 'package:a4_lab09/quote_card.dart'; //absolute path

void main() => runApp(MaterialApp(
  home: EchoList(),
));


class EchoList extends StatefulWidget {
  const EchoList({Key? key}) : super(key: key);
  @override
  State<EchoList> createState() => _EchoListState();
}
class _EchoListState extends State<EchoList> {

  List<Quote> quotes = [
    Quote(text: 'Simple living and high thinking',author:
    'prashant1'),

    Quote(author: 'prashant2', text: 'Silence and smile are two powerful tool'),
    Quote(text: 'Always do truth',author:
    'prashant3'),
  ];
  /*Widget quoteTemplate(quote){
    return QuoteCard(quote : quote,);
  }
  */

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.lightBlueAccent[100],
      appBar: AppBar(
        title: Text('Quotes'),
        centerTitle: true,
        backgroundColor: Colors.orangeAccent,
      ),
      body: Column(

        children: quotes.map((quote) => QuoteCard(
               quote: quote,
               delete: () {
                 setState(() {
                   quotes.remove(quote);
                 });
    },
        )).toList(),
      ),
    );
  }}


/*
//lab 9 second

// import 'dart:js';
import 'package:flutter/material.dart';
import 'package:lab9_10/pages/choose_location.dart';
import 'package:lab9_10/pages/home.dart';
import 'package:lab9_10/pages/loading.dart';

/*
void main() => runApp(MaterialApp(
// home: Home(),

routes: {
  '/': (context) => Loading(), // base routes....base widget file...main
}
));

file of project
// above statement will creates error...because it conflict with 'home:
Home(),
// because both statements tell flutter to initialize the app from their
given location
'/home': (context) => Home(),
'/location': (context) => ChooseLocation(),
}
));
*/

void main() => runApp(MaterialApp(
  // home: Loading(),

  initialRoute: '/home',
  routes: {
    '/' : (context) => Loading(),
    '/home' : (context) => Home(),
    '/location' : (context) => ChooseLocation(),
  }
));
*/













