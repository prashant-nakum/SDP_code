void main()  {
int i;
for(int i = 0; i < 5; i++){
print("hello ${i + 1}");
}
}