import 'package:lab2_tutorial3/lab2_tutorial3.dart';
import 'package:test/test.dart';

void main() {
  test('calculate', () {
    expect(calculate(), 42);
  });
}
