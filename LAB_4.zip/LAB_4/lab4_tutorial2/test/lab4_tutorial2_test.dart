import 'package:lab4_tutorial2/lab4_tutorial2.dart';
import 'package:test/test.dart';

void main() {
  test('calculate', () {
    expect(calculate(), 42);
  });
}
