// lab 6 code
import 'package:flutter/material.dart';
void main() => runApp(MaterialApp(
  home: Scaffold(
    appBar: AppBar(
      title:   Text('HELLO FLUTTER...MY FIRSTAPP'),
      centerTitle: true,
      backgroundColor: Colors.red,
    ),
    body: Center(
      child : Text('Hello DDU',
        style: TextStyle(
            fontSize: 25.0,
            fontWeight: FontWeight.bold,
            letterSpacing: 2.5,
            color: Colors.grey[600],
            fontFamily: 'Aboreto'
        ),
      ),
    ),
    floatingActionButton: FloatingActionButton(
      onPressed: () {},
      child: Text('Click'),
      backgroundColor: Colors.red,
    ),
  ),
));


