import 'package:lab6_tutorial1/lab6_tutorial1.dart';
import 'package:test/test.dart';

void main() {
  test('calculate', () {
    expect(calculate(), 42);
  });
}
